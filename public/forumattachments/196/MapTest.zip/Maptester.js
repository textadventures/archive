function DisplayMap(id) {
    var maps = ""
    
    var showme = id.indexOf("BR");
    if (showme != -1) 
    maps = maps + "<img src='http://i.imgur.com/CgXrS.png' style='position:absolute;left:0;top:30;opacity:1;pointer-events:none;'/>";
    
    showme = id.indexOf("PO");
    if (showme != -1) 
    maps = maps + "<img src='http://i.imgur.com/nQY5F.png' style='position:absolute;left:0;top:30;opacity:1;pointer-events:none;'/>";
    
    showme = id.indexOf("ST");
    if (showme != -1) 
    maps = maps + "<img src='http://i.imgur.com/k0fXQ.png' style='position:absolute;left:0;top:30;opacity:1;pointer-events:none;'/>";
    
    showme = id.indexOf("AF");
    if (showme != -1) 
    maps = maps + "<img src='http://i.imgur.com/SKMK1.png' style='position:absolute;left:0;top:30;opacity:1;pointer-events:none;'/>";

    addText(maps);
}
