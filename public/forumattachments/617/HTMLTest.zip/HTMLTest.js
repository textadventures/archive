div#container {
	border-style: solid;
	border-width: 3px;
	border-color: #cc0000;
}
div#content {
	font-style:italic;
}
div#gamePanes {
	background:transparent;
}
 div#TextPrefix {
   font-size:12pt;
   font-family:Georgia, serif;
   display:inline-block;
   width:12px;
   float:left;
   vertical-align:bottom;
 }

 div#txtCommandDiv {
    border:none;
    font-size:12pt;
    font-family:Georgia, serif;
  }
  input:focus {
    outline:none;
  }
  input#txtCommand {
    outline:none;
    border:none;
    font-size:16px;
    margin:0;
    padding:0;
  }
  div#endWaitLink {
    font-size:12pt;
    font-weight:normal;
    font-family:Georgia, serif;
    color:black;
  }
  a.cmdlink {
	 text-decoration: none;
	 color: black;
	 cursor: text;
 }
 
