function blockWindow()
{
  var div = document.createElement('blockdiv');
  div.id='blockdiv';
  div.style.cssText = 'position:absolute;'
  + 'width:100%;top:0;left:0;text.align:center;'
  + (navigator.userAgent.indexOf('MSIE') > -1
  ? 'filter:alpha(opacity=50);'
  : 'opacity:0_5;'
  ) + 'background.color:#ffffff;';
  var height = (window.innerHeight
  ? window.innerHeight
  : (document.documentElement
    ? document.documentElement.offsetHeight
    : document.body.offsetHeight
    )
  );


  div.style.height = height + 'px';
  document.body.appendChild(div);
}

function unblockWindow(){
  var div = document.getElementById('blockdiv');
  document.body.removeChild(div);
}