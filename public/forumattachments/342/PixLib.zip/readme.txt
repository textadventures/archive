This zip file contains various files for Quest 5.2. Besides this file there is:

PixLib.aslx: A library with several useful functions and commands. All functions are documented (but not commands) and use templates for language support. Some functions are unit tested.

PixDemo.aslx: A game that demos of some of the functions and commands in PixLib. Run the walk-through to see it all.

PixTest.aslx: A game that unit tests some of the functions and commands in PixLib. Run the walk-through to see it all.

PrettyPrintLib.aslx: A library that builds on PixLib, to format output so that the narrative text is in black and indented, and room names appear as sub-headings, while meta-game text is grey.

PrettyPrintDemo.aslx: This file is exactly the same as PixDemo.aslx except that it also invokes the PrettyPrintLib library. Run the walk-though to see the effect of the additional library.

PixLib.txt: Documentation for all the functions in PixLib, hopefully formatted for QuestWiki.