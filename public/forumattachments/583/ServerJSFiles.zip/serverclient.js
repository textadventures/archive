function connectToServer() {
  var server = new WebSocket();
  server.connect('ws://localhost:8080/');

 server.on('connect', function() {
   server.send('Connected.');
  });
}