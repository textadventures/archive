function progress() {
var progressBar = $('#progress-bar'),
    width = 100;
progressBar.width(width + '%');
var interval = setInterval(function() {
    width -= 10;
    progressBar.css('width', width + '%');
    if (width <= 0) {
        clearInterval(interval);
    }
}, 1000)
}
