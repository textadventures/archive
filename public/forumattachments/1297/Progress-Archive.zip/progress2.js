$(function progress() {
	var	$bar  = $("#progress-bar"),
		width = 100;
	$bar.css("width", width + "%");

	var intervalId = setInterval(function() {
		width = Math.max(0, width - 10);
		if (width === 0) {
			clearInterval(intervalId);
		}
		$bar.css("width", width + "%");
	}, 1000);
});