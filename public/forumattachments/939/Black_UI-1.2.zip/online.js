function testOnline() {
	if( window.location.hostname != "local") {
		ASLEvent("checkOnline", true);
	} else {
		ASLEvent("checkOnline", false);	
	}
	return false;	
}