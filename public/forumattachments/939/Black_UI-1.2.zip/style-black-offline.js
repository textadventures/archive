* {
	/*font-family: Helvetica, Arial, sans-serif !important;*/
}
:focus {
	outline-color: none;
}
body {
	background: #222222;
}
div#gameBorder {
	border: 1px solid #000;
	border-top-left-radius: 5px;
	border-top-right-radius: 5px;
}
div#gameBorder, div#gamePanel {
	background: #141414 !important;
}
div#location {
	background: url('BLACK_control.png') no-repeat 0px 0px;
	padding-left: 60px;
	margin-top: 7px;
	font-size: 14px;
}
div#gamePanel {
	margin-top: 20px;
}
div#gamePanelSpacer {
	padding-bottom: 20px;
}
div#status {
	background: url('BLACK_header-bg.jpg') top left repeat-x;
	height: 43px ;
	border: none ;
	border-top-left-radius: 5px;
	border-top-right-radius: 5px;
	width: 948px;
	border-left: 1px solid #202020;
	border-right: 1px solid #202020;
}
div#gamePanes {
	background: #000;
	margin-left: 250px;
	padding: 2px 2px 2px 7px;
	top: 43px !important;
}
#divOutput a.exitlink {
	color: #32ebfb;
}
div#gameContent {
	padding: 30px 10px 0px 20px;
}

/*panes styling*/
.ui-state-default .ui-icon {
	background-image: url('BLACK_ui-icons.png');
}
.ui-state-active .ui-icon {
	background-image: url('BLACK_ui-icons.png');
}
.ui-accordion-header {
	border: 1px solid #191919 !important;
	border-bottom: none !important;
	background: #262626 url('BLACK_bg-header-panes.jpg') top left repeat-x;
	font-weight: bold;
	color: #fff;
}
.ui-accordion-header a {
	color: #fff !important;
}
.ui-accordion .ui-accordion-content {
	background: #141414;
}
.ui-widget-content {
	border-left: 1px solid #141414;
	border-top: 1px solid #000000 !important;
	border-right: 1px solid #141414;
	border-bottom: 1px solid #141414;
	margin-top: 1px;
	color: #fff;
}
.ui-selecting
{
    background: #0e0e0e;
}
.ui-selected
{
    background: #0e0e0e;
}
.verbButtons .ui-state-default, div#controlButtons .ui-button {
	background: #2E2E2E;
	font-weight: normal;
	color: #fff;
	border: 1px solid #000;
}
div#controlButtons .ui-button {
	margin: 10px 10px 0 0 ;
}
.verbButtons .ui-state-default:hover, div#controlButtons .ui-button:hover {
	border-color: #C5DBEC;
	opacity: .35;
}
.elementListWrapper {
	overflow-y: auto;
}
.elementListWrapper::-webkit-scrollbar-track {
	/*-webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);*/
	/*border-radius: 10px;*/
	background-color: #000000;
}
.elementListWrapper::-webkit-scrollbar {
	width: 10px;
	background-color: #000000;
}
.elementListWrapper::-webkit-scrollbar-thumb {
	border-radius: 10px;
	-webkit-box-shadow: inset 0 0 6px rgba(0,0,0,.3);
	background-color: #32ebfb;
}
#compassAccordion .ui-accordion-content {
	overflow: hidden;
}

/*compass styling*/
#compassTable button.compassbutton {
	background: url('BLACK_sprite.png');
	background-position: -40px 0;
	border-radius: 0;
	border: none;
	width: 36px;
	height: 34px;
}
#compassTable button.compassbutton:hover {
	background-position: 0px 0px;
}
#compassTable button.compassbutton.ui-state-disabled:hover {
	background-position: -40px 0;
}
#compassTable button.compassbutton.ui-state-default .ui-icon {
	background: url('BLACK_sprite.png');
	width: 20px;
	height: 20px;
}
#compassTable button.compassbutton.ui-state-default .ui-icon-arrowthick-1-w {
	background-position: -1px 81px;
}
#compassTable button.compassbutton.ui-state-default .ui-icon-arrowthick-1-sw {
	background-position: -20px 80px;
}
#compassTable button.compassbutton.ui-state-default .ui-icon-arrowthick-1-s {
	background-position: -40px 82px;
}
#compassTable button.compassbutton.ui-state-default .ui-icon-arrowthick-1-se {
	background-position: -60px 80px;
}
#compassTable button.compassbutton.ui-state-default .ui-icon-arrowthick-1-e {
	background-position: -59px 61px;
}
#compassTable button.compassbutton.ui-state-default .ui-icon-arrowthick-1-ne {
	background-position: -41px 62px;
}
#compassTable button.compassbutton.ui-state-default .ui-icon-arrowthick-1-n {
	background-position: -20px 61px;
}
#compassTable button.compassbutton.ui-state-default .ui-icon-arrowthick-1-nw {
	background-position: 0px 62px;
}
#compassTable button.compassbutton.ui-state-default .ui-icon-triangle-1-n {
	background-position: -20px 62px;
}
#compassTable button.compassbutton.ui-state-default .ui-icon-triangle-1-s {
	background-position: -40px 82px;
}

#compassTable button.compassbutton.ui-state-disabled .ui-icon-arrowthick-1-w {
	background-position: -1px 39px;
}
#compassTable button.compassbutton.ui-state-disabled .ui-icon-arrowthick-1-sw {
	background-position: -20px 38px;
}
#compassTable button.compassbutton.ui-state-disabled .ui-icon-arrowthick-1-s {
	background-position: -40px 40px;
}
#compassTable button.compassbutton.ui-state-disabled .ui-icon-arrowthick-1-se {
	background-position: -60px 38px;
}
#compassTable button.compassbutton.ui-state-disabled .ui-icon-arrowthick-1-e {
	background-position: -59px 19px;
}
#compassTable button.compassbutton.ui-state-disabled .ui-icon-arrowthick-1-ne {
	background-position: -41px 20px;
}
#compassTable button.compassbutton.ui-state-disabled .ui-icon-arrowthick-1-n {
	background-position: -20px 20px;
}
#compassTable button.compassbutton.ui-state-disabled .ui-icon-arrowthick-1-nw {
	background-position: 0px 20px;
}
#compassTable button.compassbutton.ui-state-disabled .ui-icon-triangle-1-n {
	background-position: -20px 20px;
}
#compassTable button.compassbutton.ui-state-disabled .ui-icon-triangle-1-s {
	background-position: -40px 40px;
}

#compassTable button.ui-button-text-only .ui-button-text {
	background: url('BLACK_sprite.png');
	width: 30px;
	height: 20px;
	text-indent: -9999px;
}
#compassTable button#cmdCompassIn .ui-button-text {
	background-position: 49px 115px;
}
#compassTable button#cmdCompassIn.ui-state-disabled .ui-button-text {
	background-position: 33px 44px;
}
#compassTable button#cmdCompassOut .ui-button-text {
	background-position: 32px 86px;
}
#compassTable button#cmdCompassOut.ui-state-disabled .ui-button-text {
	background-position: 42px 25px;
}


.ui-state-disabled, .ui-widget-content .ui-state-disabled, .ui-widget-header .ui-state-disabled {
/*opacity: 1;*/
}

#txtCommandDiv input {
	-webkit-appearance: none;
	border: 1px solid #141414;
	color: #000 !important;
}
#txtCommandDiv input:focus {
	outline-color: #000;
}


#gamePanesFinished {
	color: #fff;
}