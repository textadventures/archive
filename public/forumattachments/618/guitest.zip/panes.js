function showObjectPaneVisible(visible) {
    if ($.parseJSON(visible)) {
        $("#placesObjectsWrapper").show();
		$("#placesObjectsButtons").show();
        $("#placesObjectsAccordion").show();
        $("#placesObjectsLabel").show();
    }
    else {
        $("#placesObjectsWrapper").hide();
		$("#placesObjectsButtons").hide();
        $("#placesObjectsAccordion").hide();
        $("#placesObjectsLabel").hide();
    }
}

function showKompassVisible(visible) {
    if ($.parseJSON(visible)) {
        $("#compassAccordion").show();
        $("#compassLabel").show();
    }
    else {
        $("#compassAccordion").hide();
		$("#compassLabel").hide();
    }
}
	
function showInventoryVisible(visible) {
    if ($.parseJSON(visible)) {
        $("#inventoryAccordion").show();
        $("#inventoryLabel").show();
    }
    else {
        $("#inventoryAccordion").hide();
		$("#inventoryLabel").hide();
    }

}

function newWindow(ress){
	var text='<br/><div id="newwindow" class="ui-accordion-content-active ui-accordion-content ui-helper-reset ui-widget-content  ui-corner-top ui-corner-bottom" style="overflow-x:hidden"><center><img id="imgid" src="' + ress + '"></center></div>';
	$("#inventoryLabel").before(text);
  }

function changePicture (ress) {
	$("#imgid").attr("src",ress);
  }	