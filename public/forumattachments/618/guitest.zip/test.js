function setAlignment(align){ 
  var i = 0;
  var obj = $('[id^=divOutputAlign]');
  while (obj[i]) {
        obj[i].setAttribute("style" , "text-align: "+align);
        i++;
    }
}	

function setBlue(){ 
  setColours("Blue", "PowderBlue", "AliceBlue")
}

function setRed(){ 
  setColours("Red", "Pink", "DarkGray")
}

function setGreen(){ 
  setColours("LimeGreen", "LightGreen", "DarkOliveGreen")
}

function setYellow(){ 
  setColours("Yellow", "LightYellow", "DarkKhaki")
}

function setGray(){ 
  setColours("Gray", "Silver", "DarkGray")
}

function setWhite(){ 
  setColours("AntiqueWhite", "WhiteSmoke", "Silver")
}

function setBlack(){ 
  setColours("Black", "DimGray", "Silver")
}

function setColours(dark, light, title){ 
  document.body.setAttribute("style" , "background: " + dark + ";");
  document.getElementById("location").setAttribute("style" , "color: " + title + ";");
  document.getElementById("status").setAttribute("style" , "background: " + dark + ";");
  document.getElementById("gameBorder").setAttribute("style" , "background: " + light + ";");
  document.getElementById("gamePanes").setAttribute("style" , "background: " + light + ";");
  document.getElementById("gamePanel").setAttribute("style" , "background: " + light + ";");
  document.getElementById("txtCommand").setAttribute("style" , "background: " + light + ";");
  
  document.getElementById('txtCommandDiv').innerHTML = '<b>></b>'+document.getElementById('txtCommandDiv').innerHTML ;
  
}