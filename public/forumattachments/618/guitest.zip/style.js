.ui-widget-header {
	border: 1px solid silver;
	background: silver;
	color: silver;
} 

body {
    font-family: Calligraffitti,Arial, Helvetica, sans-serif;
	background-color: grey;
}
.ui-widget {
	font-family:Calligraffitti,Lucida Grande,Lucida Sans,Arial,sans-serif;
}
.ui-widget input,.ui-widget select,.ui-widget textarea,.ui-widget button {
	font-family:Calligraffitti,Lucida Grande,Lucida Sans,Arial,sans-serif;
}
#compassTable .ui-button {
    font-family: Calligraffitti,Arial, Helvetica, sans-serif;
}	
div#gamePanes {
    background: silver;
}
#txtCommand {
	font-family: Calligraffitti,Arial, Helvetica, sans-serif;
	background-color: silver;
	color: black;
}	
*:focus {
    outline: none;
}
#divOutputAlign1 {
    text-align: center;
}
.ui-accordion-header {
    background: grey;
}
.ui-state-active a, .ui-state-active a:link, .ui-state-active a:visited {
	color:silver;
}
.ui-state-active, .ui-widget-content .ui-state-active, .ui-widget-header .ui-state-active {
	border: 1px solid black;
}	
.ui-widget-content {
	border: 1px solid black;
	background: silver ;
	color: #000;
}
.ui-state-default, .ui-widget-content .ui-state-default, .ui-widget-header .ui-state-default {
	border: 1px solid black;
	background: grey;
	font-weight: bold;
	color: black;
}
.ui-state-default a, .ui-state-default a:link, .ui-state-default a:visited {
	color: white;
}
#compassTable .ui-button-disabled {
	border: 1px solid white;
}
#compassTable .ui-button {
	border: 2px solid white;
}


