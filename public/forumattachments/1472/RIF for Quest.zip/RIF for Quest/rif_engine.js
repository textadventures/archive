var RifEngine = (function() {
    function loadRif(completion) {
        var self = this;
        this.load.loadTokens(this.rif_file, function (tokens) {
            rifExpand(tokens, function(tokens) {
                var rif = rifParse(tokens);
                self.world.addRif(rif);
                completion(rif);
            });
        });
    }

    function initFromParams(params) {
        var self = this;
        self.data_root = params.data_root || "data/";

        function loadFile(name, completion) {
        	console.log("in loadFile", name);
            $.ajax({
                url: self.data_root + name,
                cache: false
            })
            	.done(completion)
            	.fail(function(jqXHR, textStatus, errorThrown) {
	            	console.log("Error loading: status=", textStatus, ", error thrown=", errorThrown);
            })
            	.always(function(jqXHR, textStatus, errorThrown) {
            		console.log("always:  status=", textStatus, ", error thrown=", errorThrown);
            });
        }

        self.rif_file = params.rif_file || "rif.txt";
        self.load_file = params.load_file || loadFile;
        self.load = params.load || new rifLoad(self.load_file);

        self.world = params.world || new RifWorld();
        self.response = params.response || new RifResponse(self.world);
        self.formatter = params.formatter || new RifHtmlFormatter();
        self.dom = params.dom || new RifDOM(params.element);

    }
    var type = function(params, completion) {
        initFromParams.call(this, params);
        var self = this;

        loadRif.call(this, function(rif) {
            self.interact =  new RifInteract(self.dom, self.formatter, self.world, self.response, rif);
            completion();
        });
    };

    type.prototype.getWorld = function() {
        return this.world;
    };
    type.prototype.getInteract = function() {
        return this.interact;
    };
    return type;
})();