function init() {
	console.log("In init()");
    var params = {
        rif_file: 'helloworld.txt',
        element: $('#output'),
        data_root: 'quest://local/'
    };
    var engine = new RifEngine(params, function() {
        engine.interact.sendCommand([{keyword:"START"}]);
    });
}
