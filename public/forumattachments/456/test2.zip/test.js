function setAlignment(){ 
  var obj = document.getElementById("divOutputAlign1");
  obj.setAttribute("style" , "text-align: center");
}	

function setBlue(){ 
  setColours("Blue", "PowderBlue", "AliceBlue")
}

function setRed(){ 
  setColours("Red", "Pink", "DarkGray")
}

function setGreen(){ 
  setColours("LimeGreen", "LightGreen", "DarkOliveGreen")
}

function setYellow(){ 
  setColours("Yellow", "LightYellow", "DarkKhaki")
}

function setGray(){ 
  setColours("Gray", "Silver", "DarkGray")
}

function setWhite(){ 
  setColours("AntiqueWhite", "WhiteSmoke", "Silver")
}

function setBlack(){ 
  setColours("Black", "DimGray", "Silver")
}

function setColours(dark, light, title){ 
  document.body.setAttribute("style" , "background: " + dark + ";");
  document.getElementById("location").setAttribute("style" , "color: " + title + ";");
  document.getElementById("status").setAttribute("style" , "background: " + dark + ";");
  document.getElementById("gameBorder").setAttribute("style" , "background: " + light + ";");
  document.getElementById("gamePanes").setAttribute("style" , "background: " + light + ";");
  document.getElementById("gamePanel").setAttribute("style" , "background: " + light + ";");
  document.getElementById("textCommand").setAttribute("style" , "background: " + light + ";");
}