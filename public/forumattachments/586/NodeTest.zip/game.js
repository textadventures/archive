// Placeholder file for Node.js game server
var util = require("util"),
    io = require("socket.io");

var socket,
    players;



function init() {
	util.log("init");
	players = [];
	socket = io.listen(8000);

	socket.configure(function() {
	    socket.set("transports", ["websocket"]);
	    socket.set("log level", 20);
	});

	setEventHandlers();
}

var setEventHandlers = function() {
    socket.sockets.on("connection", onSocketConnection);
};

function onSocketConnection(client) {
    util.log("New player has connected: "+client.id);
    client.on("disconnect", onClientDisconnect);
    client.on("quest message", onQuestMessage);
//    client.on("move player", onMovePlayer);
};

function onClientDisconnect() {
    util.log("Player has disconnected: "+this.id);
};

function onQuestMessage(data) {
	util.log('onQuestMessage:' + data.msg);
};

function onMovePlayer(data) {
	util.log('onMovePlayer');
};

init();
