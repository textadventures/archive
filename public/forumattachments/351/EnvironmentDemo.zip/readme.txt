Caring for the Environment

This demo illustrates how you can add environmental effects relatively easily. By environmental effects, I mean two things:

Listening and smelling

Looking at common scenery objects

This is what we do not want:

You are in a long corridor running east-west under the great castle [etc.]
>examine wall
It's nothing special
>listen
You hear nothing
>Smell
You smell nothing

On the other hand, we also do not want to have to create specific responses for each and every room in the adventure. Instead, let us build a set of environments. One environment is for the castle, and we can put generic smell and listen responses in there, and we can add a wall object so the player can examine that. Now any room assigned to that environment automatically has walls to examine, and listen and smell responses. We might also have a forest environment, a castle_external, etc. Of course we may well want to override the generic for specific rooms too.



The Demo

The demo consists of four locations, one a hut, and three in the forest. In the hut you can examine the wall, in the forest you can examine the tree and the sky. The tree is in the "e_forest" environment, but that is inside the "e_outside" environment, which has the sky. Doing a dance in the clearing changes the sky definition for "e_outside", which changes the description for all outside rooms, and adds an "enviro_note" to outside, so as we move around outside we are told that it is raining. One room has an unusual tree showing how the generic tree for the environment can be overwritten.



The Tutorial

So let us suppose you already have a part written game with numerous rooms. Let us add some environmental effects.

1. Add the EnviromentLibrary

2. Create a new room, and call it "environment" (actually you can call it what you like, but this way you should know what it is). Click on the "Environment" tab, and put in default responses for "listen" and "smell".

3. Inside the "environment" room, create a set of objects, one for each environment. I suggest giving each the prefix "e_" so you know what they are and can find them easily in lists. Set then to be scenery.

4. For each environment object, add background objects as appropriate (wall, tree, sky, whatever). Make sure they all have descriptions, and all are set to be scenery. Now go to the "Environment" tag, and make "In this environment" point to "Environment". Put in a string for "listen" and "smell". Also add an attribute "enviro" to each environment object.

5. For each room in your game, on the "Environment" tab, make "In this environment" point to the appropriate environment object. For rooms with a specific sound or smell, just set the "listen" or "smell" attribute exactly as before; this will automaticaly take presence over the environmental value.

6. If you want a room to have a specific background object, add that object to the room as normal (you will probably want to set it as scenery too). For this new object, on the "Environment" tab, set "override this object" to the object in your hierarchy. For example, if you have an odd tree, then set this to be the "tree" object in the "e_forest" environment object.

7. Start the game, and type "tst enviro". This will check all your rooms have an "enviro" attribute, and that it is set to an object.



Messages

If you want rooms in a certain environment to have some text printed after the room description, put that text in the "Message on room enter" box for the environment object (for example, this might say that it is raining). Alternatively, use a script in", and that will be run after entering each room in that environment. Now you tell the player it is raining and set the character to be wet.



A Hierarchy

If you are feeling adventurous, you can set up your environment objects in a hierarchy by connecting them through the "enviro" attribute (using the "Link to this environment" setting), just like the rooms. For example, the room "forest_path" could link to "e_coniferous_forest", which in turn links to "e_forest", linked to "e_outside". The "e_coniferous_forest" object has a "tree" object in it, the "e_outside" object has a "sky" object. The "e_forest" object has "listen" and "smell" attributes.



More Options

Want new senses? How about a way for the player to pick up "vibes" using his sixth sense. Create a command like this:

  <command name="Sixth Sense">
    <pattern>sixth sense</pattern>
    <script>
      msg (Trawl (player.parent, "sixth", "enviro", "You sense nothing here."))
    </script>
  </command>

Then add a "sixth" attribute to the environmental objects (just look at the "listen" and "smell" attributes to see how this should work).

Or create a new hierarchy for psychic environment. Replace "enviro" with "psychic_enviro" in the above command, and set up a series of objects using the attribute "psychic_enviro" instead of "enviro". Use "tst psychic_enviro" to test every room has this set.

This could easily be adapted for "cast detect magic", etc. How about a people environment for the number of people present so you can give responses to "jump" and "dance" depending on how crowded the location is?



Language Support

To use this in a language other than English, replace the two command templates. You're done.

If you want to use the fill and empty commands, there are a few new dynamic templates to replace too.
