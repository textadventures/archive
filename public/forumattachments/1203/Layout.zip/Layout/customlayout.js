﻿function panels()
{
	$('#compassLabel').insertBefore('#inventoryLabel');
	$('#compassAccordion').insertBefore('#inventoryLabel');
	$('#statusVarsLabel').insertBefore('#inventoryLabel');
	$('#statusVarsAccordion').insertBefore('#inventoryLabel');
	$('#gridPanel').insertBefore('#compassLabel');

	var i=document.getElementById("gridPanel")
	i.style.width="216px";
	i.style.height="300px";
	i.style.position="static";
	i.style.marginLeft="0px";
	i.style.background="grey";

	var i=document.getElementById("gridCanvas")
	i.width=216;
	i.height=300;
}