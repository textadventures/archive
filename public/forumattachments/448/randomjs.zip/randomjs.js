<script language="javascript" type="text/javascript">
<!--
var diceroll=0;
var topnum=0;
function singledice(topnum)
{
window.alert("You roll the dice!");
var diceroll= Math.floor(Math.random()*topnum)+1;
//if (diceroll == 0)
//{
//diceroll = 1;
//}
window.alert("dice roll is " + diceroll);
}
//-->
</script>

</head>

<body>
<script language="javascript" type="text/javascript">

//parameter of singledice sets top number of random range
<!--

singledice (6);
window.alert("carry on!");
document.write ("go on carry on....");
//-->
</script>
</body>