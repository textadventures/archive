function inputbox(question,def) {
var r=confirm("Press a button");
var answer = prompt(question,def);
ASLEvent("Inputbox", answer);
return false;
}