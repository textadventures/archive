function CanvasTest () {
        // Get a reference to the canvas object
        var canvas = document.getElementById('gridCanvas');
        // Create an empty project and a view for the canvas:
        paper.setup(canvas);
        // Create a Paper.js Path to draw a line into it:
        var path = new paper.Path();
        // Give the stroke a color
        path.strokeColor = 'black';
        var start = new paper.Point(100, 100);
        // Move to start and draw a line from there
        path.moveTo(start);
        // Note that the plus operator on Point objects does not work
        // in JavaScript. Instead, we need to call the add() function:
        path.lineTo(start.add([ 200, -50 ]));
        // Draw the view now:
        paper.view.draw();
}

function ReplaceDrawPlayer() {
    window.oldDrawPlayer = gridApi.drawPlayer;
    console.log("drawPlayer = " + window.oldDrawPlayer);

    gridApi.drawPlayer = function (x, y, z, radius, border, borderWidth, fill) {
        console.log("called my drawPlayer!");
    }
};

function hideIt(layer) {
  document.getElementById(layer).style.visibility='hidden';
}

function showIt(layer) {
  if (document.currentLayer) {
    document.currentLayer.style.visibility = 'hidden';
  }
  document.currentLayer = document.getElementById(layer);
  document.currentLayer.style.visibility='visible';
}

function removeIt(layer) {
  var element = document.getElementById(layer)
  element.style.visibility='hidden';
  element.style.position='absolute';
}

function setText(layer, text) {
  var element = document.getElementById(layer)
  element.innerHTML=text;
}

function FadeOut(divid, delay, cb, cbParams) {
    var opacity = 1.0;
    var marginTop = 0;
    var div = document.getElementById(divid);
    div.style.opacity = opacity;
    div.style.marginTop = marginTop;
    var timer = setInterval(function() {
        opacity -= 0.1;
        div.style.opacity = opacity;
        marginTop += 1;
        div.style.marginTop = marginTop + "px";
        if (opacity <= 0.0) {
            clearInterval(timer);
            if (cb) {
                ASLEvent(cb, cbParams || "");
            }
        }
    }, delay);
}

function removeItem(array, item){
    for(var i in array){
        if(array[i]===item){
            array.splice(i,1);
            break;
        }
    }
}

function Grid_MyDrawPlayer(x, y, z, color, direction) {
    console.log("Grid_MyDrawPlayer");
    //activateLayer(z);
    if (!player) {
        player = new Path.Circle(gridPoint(x, y), 5);
        player.strokeColor = "black";
        player.strokeWidth = 2;
        player.fillColor = "blue";
        allPaths.push(player);
        
        playerPositionAbsolute = player.position - offset;
        offsetDestinationX = ($("#gridPanel").width() / 2) - playerPositionAbsolute.x;
        offsetDestinationY = ($("#gridPanel").height() / 2) - playerPositionAbsolute.y;

        offsetDestination = new Point(offsetDestinationX, offsetDestinationY);
        offsetVector = (offsetDestination - offset);
    }
    else {
        playerDestination = gridPoint(x, y);
        playerVector = (playerDestination - player.position) / 10;
        paper.view.zoom = 1;
        // move player to the end of the activeLayer so it gets drawn on top
        project.activeLayer.addChild(player);
    }
    player.opactity = 0.5;
}
