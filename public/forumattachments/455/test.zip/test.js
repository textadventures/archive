function setAlignment(){ 
	var obj,attr;
	obj=document.getElementById("divOutputAlign1");
	attr=obj.getAttribute ("style");
	obj.setAttribute("style" , "text-align: center");
}	
