var thisYtDivId = null;
var ytDivCount = 0;

function AddYouTubeDiv(id) {
    var url = "http://www.youtube.com/v/" + id + "?version=3&autoplay=1";
    ytDivCount++;
    thisYtDivId = "youtubediv" + ytDivCount;
    var embedHTML = "<div id=\"" + thisYtDivId + "\"><object width=\"425\" height=\"344\"><param name=\"movie\" value=\"" + url + "\"></param><param name=\"allowFullScreen\" value=\"true\"></param><param name=\"allowscriptaccess\" value=\"always\"></param><param name=\"wmode\" value=\"transparent\"></param><embed wmode=\"transparent\" src=\"" + url + "\" type=\"application/x-shockwave-flash\" allowscriptaccess=\"always\" allowfullscreen=\"true\" width=\"425\" height=\"344\"></embed></object></div>";
    addText(embedHTML);
}

function HideYouTubeDiv() {
    $("#" + thisYtDivId).hide();
}