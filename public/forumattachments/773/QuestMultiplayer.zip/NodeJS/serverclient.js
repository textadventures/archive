var socket;
function connectToServer(ip, port) {
    socket = io.connect('http://' + ip + ':' + port + '/', {'max reconnection attempts': 0});

    // Add a connect listener
    socket.on('connect',function() {
	    ASLEvent('Log', 'Client has connected to the server.');
		ASLEvent('OutputTextNoBr', '<script>document.getElementById(\'reconnectMessage\').innerHTML = \'Reconnected successfully.\';</script>');
		ASLEvent('BeginGame', '');
    });
	// Connecting listener
	socket.on('connecting', function() {
		ASLEvent('Log', 'Connecting to the server...');
	});
	// Add a connection failure listener
	socket.on('error', function() {
		ASLEvent('OutputText', 'Could not connect to the server. Please try again later.');
	});
	// Add a reconnect listener
	socket.on('reconnect', function() {
		ASLEvent('Log', 'Client has reconnected to the server!');
		ASLEvent('BeginGame', '');
	});
	// Reconnect on error
	socket.on('reconnecting', function() {
		ASLEvent('OutputText', '<span id="reconnectingMessage">You have lost connection to the server. Attempting to reconnect...</span>');
	});
	// Add a reconnection failure listener
	socket.on('reconnect_failed', function() {
		ASLEvent('OutputTextNoBr', '<script>document.getElementById(\'reconnectingMessage\').innerHTML = \'Failed to reconnect.\';</script>');
	});
    // Listen for messages
    socket.on('serverMessage', function(message) {
		ASLEvent('Log', 'Writing server message...');
	    ASLEvent('FSBroadcastMessage', message);
    });
	// Listen for object movement
	socket.on('moveObject',function(object) {
	    ASLEvent('Log', 'Moving object: ' + object.name + ' to ' + object.location);
		ASLEvent('FSMoveObject', object.name + '; ' + object.location);
	});
	// Listen for new objects
	socket.on('createObject', function(data) {
		ASLEvent('Log', 'Creating new object: ' + data.o + ' of type ' + data.t);
	    ASLEvent('FSCreate', data.o + '; ' + data.t);
	});
	// Listen for new players
	socket.on('createPlayer', function(player) {
	    ASLEvent('Log', 'Creating player: ' + player.name + ' at ' + player.location);
	    ASLEvent('FSCreatePlayer', player.name + '; ' + player.location);
	});
	// Listen for object attributes
	socket.on('setAttribute', function(data) {
		ASLEvent('Log', 'Setting attribute: ' + data.o + '.' + data.a + ' as ' + data.v);
		ASLEvent('FSSetAttribute', data.o + '; ' + data.a + '; ' + data.v);
	});
	// Listen for chatting
	socket.on('chatSay', function(data) {
		ASLEvent('FSChatReceive', data.p + '; ' + data.msg);
	});
	socket.on('chatPrivate', function(data) {
		ASLEvent('FSPrivateMessage', data.p + '; ' + data.msg);
	});
	// Listen for players taking objects
	socket.on('takeObject', function(data) {
		ASLEvent('FSPlayerTook', data.p + '; ' + data.o);
	});
	// Listen for request of original locations
	socket.on('originalLocations', function() {
		ASLEvent('FSOriginalLocations', '');
	});
	// Listen for players dropping objects
	socket.on('dropObject', function(data) {
		ASLEvent('FSPlayerDropped', data.p + '; ' + data.o);
	});
	// Listen for Quest functions (should only be used for testing)
	socket.on('runFunction', function(data) {
		ASLEvent(data.func, data.params);
	});
    // Add a disconnect listener
    socket.on('disconnect', function(player) {
		if (player.name !== this.id) {
			ASLEvent('Log', 'The client ' + player.name + ' has disconnected!');
			ASLEvent('FSDestroy', player.name);
		}
		else {
			socket.socket.reconnect();
		};
    });
};

// Sends a message to the server via sockets
function serverMessage(message) {
    ASLEvent('Log', 'Sending server message: ' + message);
    socket.emit('serverMessage', message);
};
// Moves objects on the server
function moveObject(object, location) {
    ASLEvent('Log', 'Updating other clients...');
	socket.emit ('moveObject', { o: object, l: location });
};
// Moves player-specific objects on the server
function movePlayer(location) {
	ASLEvent('Log', 'Updating other clients...');
	socket.emit('movePlayer', location);
};
// Creates objects on the server
function createObject(object, type) {
    ASLEvent('Log', 'Updating other clients...');
	socket.emit('createObject', { o: object, t: type });
};
// Creates player-specific objects on the server
function createPlayer(name, location) {
    ASLEvent('Log', 'Updating other clients...');
    this.id = name;
    socket.emit('createPlayer', { o: name, l: location });
};
// Sets object attributes on the server
function setObjectAttribute(object, attribute, value) {
	socket.emit('setAttribute', { o: object, a: attribute, v: value, p: false });
};
// Sets player attribute on the server
function setPlayerAttribute(player, attribute, value) {
    socket.emit('setAttribute', { o: player, a: attribute, v: value, p: true });
};
// Chat with other users
function chatSay(message) {
	ASLEvent('Log', 'Sending message: ' + message);
    ASLEvent('OutputText', '<font color="green">You:</font> ' + message);
	socket.emit('chatSay', message);
};
// Send PM to specific user
function chatPrivate(to, message) {
	ASLEvent('Log', 'Sending message to ' + to + ': ' + message);
	ASLEvent('OutputText', '<font color="blue">To ' + to + ':</font> ' + message);
	socket.emit('chatPrivate', { to: to, msg: message });
};
// User takes object
function takeObject(object) {
	socket.emit('takeObject', object);
};
// User drops object
function dropObject(object) {
	socket.emit('dropObject', object);
};
// Send original object locations
function originalLocations(list) {
	socket.emit('originalLocations', list);
};
// Move object to original location
function toOriginalLoc(object) {
	socket.emit('toOriginalLoc', object);
};
// Log to Node
function logToConsole(message) {
	socket.emit('log', message);
};
// Send any function to Quest (should only be used for testing)
function runFunction(func, params, emit) {
	ASLEvent(func, params);
	if (emit === true) {
		socket.emit('runFunction', { func: func, params: params });
	};
};