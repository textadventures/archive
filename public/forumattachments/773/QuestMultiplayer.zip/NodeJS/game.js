String.prototype.endsWith = function(suffix) {
    return this.indexOf(suffix, this.length - suffix.length) !== -1;
};

Array.prototype.remove = function() {
    var what,
		a = arguments,
		L = a.length,
		ax;
    while (L && this.length) {
        what = a[--L];
        while ((ax = this.indexOf(what)) !== -1) {
            this.splice(ax, 1);
        }
    }
    return this;
};

var util = require("util"),
    io = require("socket.io");

var socket,
    players,
	objects;

var cyan = '\033[36m',
	red = '\033[31;1m',
	green = '\033[32;1m',
	clear = '\033[0m';
	

function init() {
	console.log(cyan + "   info  - " + clear + "Starting Quest server...");
	players = [];
	objects = [];
	socket = io.listen(8000);

	socket.configure(function() {
	    socket.set("transports", ["websocket"]);
	    socket.set("log level", 1);
	});

	setEventHandlers();
};

var setEventHandlers = function() {
    socket.sockets.on("connection", onSocketConnection);
};

function qPlayer(name, location) {
    this.location = location;
    this.name = name;
    this.attributes = [];
    this.attributes["isaplayer"] = true;
};

function qObject(name, location) {
    this.name = name;
    this.originalLocation = location;
    this.location = location;
    this.attributes = [];
    this.attributes["isaplayer"] = false;
};

function onSocketConnection(client) {
	if (objects[0] == null) {
		socket.sockets.socket(client.id).emit('originalLocations');
	};
	if (client.username == null) {
		util.log(green + "New player has connected: "+ client.id + clear);
		client.number = players.length++;
        client.initialized = false;
		client.inv = [];
	}
	else {
		util.log(green + "Player has reconnected: " + client.username + clear);
	};
    client.on("disconnect", onClientDisconnect);
    client.on("serverMessage", onServerMessage);
	client.on("moveObject", onMoveObject);
	client.on("createObject", onCreate);
	client.on("createPlayer", onCreatePlayer);
	client.on("chatSay", onChatSay);
	client.on("chatPrivate", onChatPrivate);
	client.on("movePlayer", onMovePlayer);
	client.on("setAttribute", onSetAttribute);
	client.on("takeObject", onTakeObject);
	client.on("dropObject", onDropObject);
	client.on("originalLocations", onOriginalLocations);
	client.on("toOriginalLoc",onToOriginalLoc);
	client.on("log", onLog);
	client.on("runFunction", onRunFunction);
    if (players.length > 0) {
        for (var p in players) {
            if (players[p].id !== client.number) {
                client.emit("createPlayer", players[p]);
                for (var a in players[p].attributes) {
                    client.emit("setAttribute", { o: players[p].name, a: a, v: players[p].attributes[a] });
                };
            };
        };
	};
    if (objects.length > 0) {
        for (var o in objects) {
            client.emit("moveObject", objects[o]);
            for (var a in objects[o].attributes) {
                client.emit("setAttribute", { o: objects[o].name, a: a, v: objects[o].attributes[a] });
            };
        };
	};
};

function onClientDisconnect() {
	if (this.initialized) {
        util.log(red + "Player has disconnected: " + this.username + clear);
		this.broadcast.emit('disconnect', players[this.username]);
	    delete players[this.username];
	}
    else {
        util.log(red + "Player has disconnected: " + this.id + clear);
    };
};

function onServerMessage(message) {
	if (message.endsWith(' has joined the server.')) {
		this.broadcast.emit('serverMessage', message);
	}
	else {
		socket.sockets.emit('serverMessage', message);
		console.log(cyan + '   info  - ' + clear + 'Sent server message: ' + message);
	};
};

function onMoveObject(data) {
	util.log('Moving object ' + data.o + ' to ' + data.l);
	objects[data.o].location = data.l;
	this.broadcast.emit('moveObject', objects[data.o]);
};

function onMovePlayer(location) {
	util.log('Moving player ' + green + this.username + clear + ' to \'' + location + '\'');
	players[this.username].location = location;
	this.broadcast.emit('moveObject', players[this.username]);
};

function onCreate(data) {
    util.log('Creating object: ' + data.o + ' of type ' + data.t);
	this.broadcast.emit('createObject', { o: data.o, t: data.t });
};

function onCreatePlayer(data) {
	util.log('Changing ' + this.id + ' to ' + data.o + ' and moving to ' + data.l);
	this.username = data.o;
	players[this.username] = new qPlayer(this.username, data.l);
    players[this.username].id = this.number;
    this.initialized = true;
	this.broadcast.emit('createPlayer', players[this.username]);
};

function onSetAttribute(data) {
	util.log('Setting attribute: ' + data.o + '.' + data.a + ' to ' + data.v);
    if (data.p) {
        players[data.o].attributes[data.a] = data.v;
    }
    else {
        objects[data.o].attributes[data.a] = data.v;
    };
	this.broadcast.emit('setAttribute', { o: data.o, a: data.a, v: data.v });
};

function onChatSay(message) {
    util.log("[" + players[this.username].location + "] " + this.username + ": " + message);
	this.broadcast.emit('chatSay', { p: this.username, msg: message });
};

function onChatPrivate(data) {
	socket.sockets.socket(usernames[data.to]).emit('chatPrivate', { p: this.username, msg: data.msg });
};

function onTakeObject(object) {
	util.log(this.username + ' has taken ' + object);
	this.broadcast.emit('takeObject', { p: this.username, o: object });
    objects[object].location = this.username;
	this.inv.push(object);
};

function onDropObject(object) {
	util.log(this.username + ' has dropped ' + object);
	this.broadcast.emit('dropObject', { p: this.username, o: object });
    objects[object].location = players[this.username].location;
	this.inv.remove(object);
};

function onOriginalLocations(list) {
	var objs = list.split("; ");
	var objloc;
	for (var n=0; n<objs.length; n++) {
		objloc = objs[n].split("=");
		objects[objloc[0]] = new qObject(objloc[0], objloc[1]);
	};
	util.log('Received original locations.');
};

function onToOriginalLoc(object) {
    var obj = objects[object];
	util.log('Moving object ' + object + ' to ' + obj.originalLocation);
    obj.location = obj.originalLocation;
	this.broadcast.emit('moveObject', obj);
};

function onLog (message) {
	util.log(message);
};

function onRunFunction(data) {
	util.log('Running function (' + data.func + ') with parameters: ' + data.params);
	this.broadcast.emit('runFunction', { func: data.func, params: data.params });
};

init();
