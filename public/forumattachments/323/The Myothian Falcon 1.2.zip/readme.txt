
==========================================================================
 
                        The Myothian Falcon

==========================================================================



The Myothian Falcon is a work of Interactive Fiction created for IFcomp 2011, during August and September 2011, and is my first piece of interactive fiction. The competition seemed a useful way to publicise a game that I was hoping would be finished around the deadline anyway.
 
The Myothian Falcon was written using and for Quest 5, which was created and is supported by Alex Warren, for which I am grateful. Hopefully this entry will also praise the profile of Quest 5 in the IF community too.
http://www.textadventures.co.uk/quest/download/
 
Thanks also to the following for helpful comments during beta-testing: Alex Warren; Jonathon Dobson; dacharya64. I would have loved to have more beta-testers, but if people do not offer their services...
 
The Myothian Falcon is copyright 2011 Andy Joel. It may be distributed for free. It may not be sold or included in any for-profit collection or modified without written permission from the author. If I later release the code, anything in a library file may be used and modified freely.


Anything below here in this file may contain spoilers; please play the game first. If you are stuck, type "help" in game for some general advice without spoilers, or "walkthough" for more explocit instructions.







































===============  CONTAINS  SPOILERS   ===============






























== AUTHORS NOTE ==


... because I cannot explain anything during the judging time


Hopefully you will have completed the game by now, and have convince Detective Munroe that Fenton Green murdered Lawrence DeValle and returned the Myothian Falcon.



--- What is going on?  --

Here is what happened (and in theory this should all be clear; I write this in case you think otherwise): 

About seven months ago, Dr George Lancing stole the Myothian Falcon from a Uralgan temple some 170 km from New Chicago, accompanies by his assistenant, Ursula Nguyen. Caring more for money, he sold the artefact to Lawrence DeValle for 450,000 credits, a keen collector of Uralgan art. Naturally the theft was noticed, but it took the Uralgans some months to track the culprit down to Lancing. They visited him, saying they wanted it back, but he had sold it. Eventually he admitted selling it to DeValle. They killed him 9or executed him) for the theft.

Lawrence DeValle has a thing for Uralga women. His wife was one, and that kept him happy for a time, but she made herself look human (hence, the wigs in the mansion); after a while, Lawrence craved real Uralgans. He became a regular at the Green Heaven, and started to have an affair with a dancer there called Petharla.

One of the people they used to track down George Lancing was a small time crook called Larry Yang (you cannot meet Larry in the game, by the way). Larry reported to his boss, Nikki Stum, and she decided she wanted the artefact herself. She sent Bram Fenton to steal it for her, intending to sell it to the highest bidder - off-world if necessary.

Fenton was none too bright, but had a lucky break - the security had been disabled. Lawrence was spending the night with his Uralgan lover, and had turned it off to hide the traces. Fenton sneaked into the house. What should have been an easy job went very wrong when DeValle appeared at the front door, just back from his love nest.

The Myothian Falcon has mystical powers, and any male holding it will see nightmarish delusions - just as Vic did when he picked it up. They do not last long, it was just unfortunately that at that moment DeValle appeared. Fenton thought he was shooting a terrible monster.

When Maisy found the dead body she panicked. Although Lawrence knew she was a Uralgan, no one else did; she was desprate to keep it that way, so fleed the crime scene.


Did you ask any of the women about a date, by the way? Vic can get lucky with one of them.


--- Obscure References  ---

The game is loosely inspired by "The Maltese Falcon", an item that is described in the movie as "the stuff that dreams are made of". Thus, the Myothian Falcon induces hallucinations (it has nothing to do with the Millenium Falcon).

The gun has an anti-Chekhov damping system. As I am sure you realised, this was a reference to "Chekhov's gun"; an anti-Chekhov damping system indicates the gun should NOT be used later on. 

Detective Jill Munroe later joined Charlie's Angels, of course (actually she was called Munroe first; the connection came later). The original Portrait of a Gazelle was features in a Thunderbirds episode, the Duchess Assignment.


---  Third person, past tense?  ---

Most fiction is written in the third person, past tense, so why is interactive fiction different? What I like about the third person is that the author can create a character. It is not YOU exploring an unknown world, it is Vic Gantry in a world known to him. This is a guy with a history - just like any pretty much any novel. As he sees things, the author can not only describe what the thing is, but also what it means to Vic Gantry.

Something I hasve tried to do is to differentiate between the narrative and the metadata. The metadata is in the conventional IF first/second person, present tense, grey text. The narrative, the part I want the reader/player to focus on, is done as traditional text, third person, past tense, indented paragraphs, in black text. Does it work?


