$(function() {
  var $placesObjectsLabel = $("#placesObjectsLabel");
  var $placesObjects = $placesObjectsLabel.next();
  $placesObjectsLabel.hide();
  $placesObjects.hide();
});

$(function() {
  var $compassLabel = $("#compassLabel");
  var $compass = $compassLabel.next();
  $compassLabel.hide();
  $compass.hide();
});