var myGridApi = {}
//var scale, gridX, gridY, player
//var playerVector, playerDestination;
//var offsetVector, offsetDestination;
myGridApi.allPaths = [];
myGridApi.customLayerPaths = [];
myGridApi.customLayerObjects = {};
myGridApi.layers = [];
myGridApi.maxLayer = 3;
myGridApi.currentLayer = 0;
myGridApi.offset = new paper.Point(0, 0);
myGridApi.firstBox = true;
myGridApi.firstScale = true;
myGridApi.players = [];

myGridApi.onLoad = function() {
    var uc = updateCompass;
    updateCompass = function(listData) {
        console.log(listData);
        uc(listData + "/forward/left/right");
    }
    // Hack: Remove any existing projects and tools.
    // This will undo the setup for the internal Quest grid code.
    while (paper.projects.length)
        paper.projects[0].remove();
    while (paper.tools.length)
        paper.tools[0].remove();

    // Now setup our project.
    paper.setup(document.getElementById('gridCanvas'));
    for (var i = -this.maxLayer; i <= this.maxLayer; i++) {
        var layer = new paper.Layer();
        this.layers.push(paper.project.activeLayer);
    }
    this.customLayer = new paper.Layer();
    this.customLayer.visible = false;
    this.activateLayer(this.currentLayer);
    
    paper.view.onFrame = this.onFrame.bind(this);

    var tool = new paper.Tool();

    tool.onMouseDrag = this.onMouseDrag.bind(this);
    tool.onMouseUp = this.onMouseUp.bind(this);
//        // Create a Paper.js Path to draw a line into it:
//        var path = new paper.Path();
//        // Give the stroke a color
//        path.strokeColor = 'black';
//        var start = new paper.Point(100, 100);
//        // Move to start and draw a line from there
//        path.moveTo(start);
//        // Note that the plus operator on Point objects does not work
//        // in JavaScript. Instead, we need to call the add() function:
//        path.lineTo(start.add([ 200, -50 ]));
//        // Draw the view now:
//        paper.view.draw();
}

myGridApi.customLayerOffset = new paper.Point(0, 0);

myGridApi.activateLayer = function(index) {
    this.showCustomLayer(false);
    this.layers[this.getLayerIndex(index)].activate();
    this.layers[this.getLayerIndex(index)].opacity = 1;
    if (this.currentLayer != index) {
        this.layers[this.getLayerIndex(this.currentLayer)].opacity = 0.2;
        this.currentLayer = index;
    }
}

myGridApi.getLayerIndex = function(index) {
    if (index < -this.maxLayer || index > this.maxLayer) {
        alert("Layer out of bounds. Current layer range: -" + this.maxLayer + " to " + this.maxLayer);
    }
    // layers array represents z-indexes from -maxLayer to maxLayer
    return index + this.maxLayer;
}

myGridApi.setScale = function (newScale) {
    if (this.firstScale) {
        this.onLoad()
        this.firstScale = false;
    }
    myGridApi.scale = newScale;
    myGridApi.gridDims = paper.Point.create(this.scale, this.scale);
}

myGridApi.setZoom = function (zoom) {
    paper.view.zoom = zoom;
}

myGridApi.zoomIn = function (amount) {
    paper.view.zoom = paper.view.zoom * (Math.pow(1.1, amount));
}

myGridApi.updateOffset = function(delta) {
    this.setOffset(this.getOffset().add(delta));
    var paths;
    if (paper.project.activeLayer == this.customLayer) {
        paths = this.customLayerPaths;
    }
    else {
        paths = this.allPaths;
    }
    for (var i = 0; i < paths.length; i++) {
        var position = paths[i].getPosition();
        position.x += delta.x;
        position.y += delta.y;
    }
    if (this.playerDestination && paper.project.activeLayer != this.customLayer) {
        this.playerDestination.x += delta.x;
        this.playerDestination.y += delta.y;
    }
}

myGridApi.getOffset = function() {
    if (paper.project.activeLayer == this.customLayer) {
        return this.customLayerOffset;
    }
    return this.offset;
}

myGridApi.setOffset = function(value) {
    if (paper.project.activeLayer == this.customLayer) {
        this.customLayerOffset = value;
    }
    else {
        this.offset = value;
    }
}

myGridApi.onMouseDrag = function(event) {
    this.updateOffset(event.delta);
}

myGridApi.onMouseUp = function(event) {
    var x = this.getGridSquareX(event.point);
    var y = this.getGridSquareY(event.point);
    console.log("up: x = " + x + ", y=" + y);
    ASLEvent("JS_GridSquareClick", x + ";" + y);
}

myGridApi.onFrame = function(event) {
    if (this.playerVector) {
        var distance = this.player.getPosition().subtract(this.playerDestination);
        if (distance.getLength() > this.playerVector.getLength()) {
            this.player.getPosition().x += this.playerVector.x;
            this.player.getPosition().y += this.playerVector.y;
        }
        else {
            this.player.setPosition(this.playerDestination);
            this.playerVector = null;
            this.playerDestination = null;

            var playerPositionAbsolute = this.player.getPosition().subtract(this.offset);
            var offsetDestinationX = ($("#gridPanel").width() / 2) - playerPositionAbsolute.x;
            var offsetDestinationY = ($("#gridPanel").height() / 2) - playerPositionAbsolute.y;

            this.offsetDestination = new paper.Point(offsetDestinationX, offsetDestinationY);
            this.offsetVector = new paper.Point((this.offsetDestination.x-this.offset.x) / 10, (this.offsetDestination.y-this.offset.y) / 10);
        }
    }
    if (this.offsetVector) {
        var distance = this.offset.subtract(this.offsetDestination);
        if (distance.getLength() > this.offsetVector.getLength()) {
            this.updateOffset(this.offsetVector);
        }
        else {
            this.updateOffset(this.offsetDestination.subtract(this.offset));
            this.offsetVector = null;
            this.offsetDestination = null;
        }
    }
}

myGridApi.gridLine = function(start, end) {
    var path = new paper.Path();
    path.strokeColor = border;
    path.add(start, end);
    this.addPathToCurrentLayerList(path);
}

myGridApi.drawGrid = function (minX, minY, maxX, maxY, border) {
    // draw the vertical lines
    for (var x = minX; x <= maxX; x++) {
        var start = this.gridPoint(x, minY)
        var end = this.gridPoint(x, maxY);
        this.gridLine(start, end);
    };

    // draw the horizontal lines
    for (var y = minY; y <= maxY; y++) {
        var start = this.gridPoint(minX, y)
        var end = this.gridPoint(maxX, y);
        this.gridLine(start, end);
    };
}

myGridApi.gridPoint = function(x, y) {
    var offset = this.getOffset();
    return paper.Point.create(this.gridDims.x*x + offset.x, this.gridDims.y*y + offset.y);
}

myGridApi.getGridSquareX = function(point) {
    return Math.floor((point.x - this.getOffset().x)/this.gridDims.x);
}

myGridApi.getGridSquareY = function(point) {
    return Math.floor((point.y - this.getOffset().y)/this.gridDims.y);
}

myGridApi.gridPointNudge = function(x, y, nudgeX, nudgeY) {
    var result = this.gridPoint(x, y);
    result.x += nudgeX;
    result.y += nudgeY;
    return result;
}

myGridApi.drawBox = function (x, y, z, width, height, border, borderWidth, fill, sides) {
    this.activateLayer(z);
    // if this is the very first room, centre the canvas by updating the offset
    if (this.firstBox) {
        var centrePoint = this.gridPoint(x + width / 2, y + height / 2);
        var offsetX = ($("#gridPanel").width() / 2) - centrePoint.x;
        var offsetY = ($("#gridPanel").height() / 2) - centrePoint.y;
        this.updateOffset(new paper.Point(offsetX, offsetY));
        this.firstBox = false;
    }
    var path = null;
    var points = [this.gridPoint(x, y), this.gridPoint(x + width, y), this.gridPoint(x + width, y + height), this.gridPoint(x, y + height)];
    // sides is encoded with bits to represent NESW
    var draw = [sides & 8, sides & 4, sides & 2, sides & 1];
    for (var i = 0; i < 4; i++) {
        var next = (i + 1) % 4;
        if (draw[i]) {
            if (path == null) {
                path = new paper.Path();
                this.allPaths.push(path);
                if (borderWidth > 0) {
                    path.strokeColor = border;
                    path.strokeWidth = borderWidth;
                }
                path.add(points[i]);
            }
            path.add(points[next]);
        }
        else {
            path = null;
        }
    }
    var fillPath;
    if (sides == 15) {
        fillPath = path
    }
    else {
        fillPath = new paper.Path();
        fillPath.add(points[0], points[1], points[2], points[3]);
        this.allPaths.push(fillPath);
    }
    fillPath.fillColor = fill;
    fillPath.closed = true;
}

myGridApi.drawLine = function (x1, y1, x2, y2, border, borderWidth) {
    var path = new paper.Path;
    path.strokeColor = border;
    path.strokeWidth = borderWidth;
    path.add(this.gridPoint(x1, y1));
    path.add(this.gridPoint(x2, y2));
    this.addPathToCurrentLayerList(path);
}

myGridApi.addPathToCurrentLayerList = function(path) {
    if (paper.project.activeLayer == this.customLayer) {
        this.customLayerPaths.push(path);
    }
    else {
        this.allPaths.push(path);
    }
}

myGridApi.drawPlayer = function (x, y, z, border, fill, angle) {
    this.activateLayer(z);
    if (!this.player || this.player.angle != angle) {
        if (this.player)
            this.player.remove();
        var point = this.gridPoint(x, y);
        var cx = point.x;
        var cy = point.y;
        this.player = new paper.Path();
        this.player.strokeColor = border;
        this.player.strokeWidth = 1;
        this.player.fillColor = fill;
        this.player.angle = angle;
        this.player.add(cx, cy-8);
        this.player.add(cx+6, cy+8);
//        this.player.add(cx, cy+4);
//        this.player.add(cx-6, cy+8);
        this.player.arcTo(new paper.Point(cx, cy+6), new paper.Point(cx-6, cy+8));
        this.player.add(cx, cy-8);
        this.player.rotate(angle);
        this.allPaths.push(this.player);
        
        var playerPositionAbsolute = this.player.getPosition().subtract(this.offset);
        var offsetDestinationX = ($("#gridPanel").width() / 2) - playerPositionAbsolute.x;
        var offsetDestinationY = ($("#gridPanel").height() / 2) - playerPositionAbsolute.y;

        this.offsetDestination = new paper.Point(offsetDestinationX, offsetDestinationY);
        this.offsetVector = (this.offsetDestination.subtract(this.offset));
    }
    else {
        this.playerDestination = this.gridPoint(x, y);
        this.playerVector = new paper.Point((this.playerDestination.x - this.player.getPosition().x) / 10,  (this.playerDestination.y - this.player.getPosition().y) / 10);
        paper.view.zoom = 1;
        // move player to the end of the activeLayer so it gets drawn on top
        paper.project.activeLayer.addChild(this.player);
    }
    //player.opactity = 0.5;
}

myGridApi.drawLabel = function (x, y, z, text) {
    this.activateLayer(z);
    var pointText = new paper.PointText(this.gridPoint(x, y));
    pointText.justification = "center";
    pointText.fillColor = "black";
    pointText.content = text;
    this.allPaths.push(pointText);
}

myGridApi.showCustomLayer = function(visible) {
    if (visible != this.customLayer.visible) {
        this.customLayer.visible = visible;
        for (var idx = 0; idx < this.layers.length; idx++) {
            this.layers[idx].visible = !visible;
        }
        if (visible) {
            this.customLayer.activate();
        }
        else {
            this.layers[this.getLayerIndex(this.currentLayer)].activate();
        }
    }
}

myGridApi.clearCustomLayer = function () {
    this.customLayer.removeChildren();
}

myGridApi.setCentre = function (x, y) {
    var centrePoint = this.gridPoint(x, y);
    var offsetX = ($("#gridPanel").width() / 2) - this.centrePoint.x;
    var offsetY = ($("#gridPanel").height() / 2) - this.centrePoint.y;
    //var curOffset = this.getOffset();
    this.updateOffset(new paper.Point(offsetX, offsetY));
}

myGridApi.drawCustomLayerSquare = function (id, x, y, width, height, text, fill) {
    var existing = this.customLayerObjects[id];
    if (existing) {
        for (var idx in existing) {
            var path = existing[idx];
            // TO DO: Should remove path from layer and layerlist array
            path.visible = false;
        }
    }

    var paths = new Array();
    path = new paper.Path();
    path.add(this.gridPointNudge(x, y, 1, 1), this.gridPointNudge(x + width, y, -1, 1), this.gridPointNudge(x + width, y + height, -1, -1), this.gridPointNudge(x, y + height, 1, -1));
    path.fillColor = fill;
    path.closed = true;
    this.addPathToCurrentLayerList(path);
    paths.push(path);

    var pointText = new paper.PointText(gridPoint(x + width/2, y + height/2));
    pointText.justification = "center";
    pointText.fillColor = "black";
    pointText.content = text;
    this.addPathToCurrentLayerList(pointText);
    paths.push(pointText);

    this.customLayerObjects[id] = paths;
}

//$(function() {
//    myGridApi.onLoad();
//});

function MyGrid_Setup() {
    myGridApi.onLoad();
}


////////////////////////////////////////////////////////////////////////////
function MyGrid_DrawGridLines(minX, minY, maxX, maxY, border) {
    if (_canvasSupported)
        myGridApi.drawGrid(parseInt(minX), parseInt(minY), parseInt(maxX), parseInt(maxY), border);
}

function MyGrid_SetScale(scale) {
    if (_canvasSupported)
        myGridApi.setScale(parseInt(scale));
}

function MyGrid_DrawBox(x, y, z, width, height, border, borderWidth, fill, sides) {
    if (_canvasSupported)
        myGridApi.drawBox(parseFloat(x), parseFloat(y), parseFloat(z), parseInt(width), parseInt(height), border, parseInt(borderWidth), fill, parseInt(sides));
}

function MyGrid_DrawLine(x1, y1, x2, y2, border, borderWidth) {
    if (_canvasSupported)
        myGridApi.drawLine(parseFloat(x1), parseFloat(y1), parseFloat(x2), parseFloat(y2), border, parseInt(borderWidth));
}

function MyGrid_DrawPlayer(x, y, z, radius, border, borderWidth, fill) {
    if (_canvasSupported)
        myGridApi.drawPlayer(parseFloat(x), parseFloat(y), parseFloat(z), parseInt(radius), border, parseInt(borderWidth), fill);
}

function MyGrid_DrawLabel(x, y, z, text) {
    if (_canvasSupported)
        myGridApi.drawLabel(parseFloat(x), parseFloat(y), parseFloat(z), text);
}

function MyGrid_ShowCustomLayer(visible) {
    if (_canvasSupported)
        myGridApi.showCustomLayer(visible == "true");
}

function MyGrid_ClearCustomLayer() {
    if (_canvasSupported)
        myGridApi.clearCustomLayer();
}

function MyGrid_SetCentre(x, y) {
    if (_canvasSupported)
        myGridApi.setCentre(parseFloat(x), parseFloat(y));
}

function MyGrid_DrawSquare(id, x, y, width, height, text, fill) {
    if (_canvasSupported)
        myGridApi.drawCustomLayerSquare(id, parseInt(x), parseInt(y), parseInt(width), parseInt(height), text, fill);
}

