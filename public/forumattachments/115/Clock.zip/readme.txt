The Pixie Clock Library

This library will help you to track time during the game. Time is incremented whenever the player takes a turn, starting from midnight on day 1. By default, moving to another room will take 5 minutes, any other action will take 1 minute. If the player types "clock" she will discover the time.


What you can also do:

Set the start time
In the game.start script, call IncTime to set the time in game starts in minutes past midnight.

Have the time displayed as a status variable
Add the attribute "clock" to the player, and set it to string. Then add it as a status variable. It will automatically track the time.

Have long distance exits
You can change the time that passes when a specific exit is used by calling the LongExit function. Call the function in a script on the exit, with the parameters, this, and the time to elapse.

    <exit alias="north" to="distance_room">
      <inherit name="northdirection" />
      <script type="script">
        LongExit (this, 45)
      </script>
    </exit>

Have exits open at different times
You can also have exits that can only be used at certain times. There is not a lot of control over this. The day is divided into six hour slots, and you can specify which are open with the third parameter to the BusinessExit function. This should be a 4 character string, each character corresponding to a six hour slot, n indicates not open, y indicates yes it is.

    <exit alias="west" to="business_room">
      <inherit name="westdirection" />
      <script type="script">
        BusinessExit (this, 5, "nynn")
      </script>
    </exit>


Convenience functions

In addition, there are a number of functions available that will hopefully make life easier for others..

GetTime
IncTime(int)
IsAfternoon
IsBusinessClosed(string)
IsEvening
IsDusk
IsMorning
IsNight
PartOfDay
TimeAsString
