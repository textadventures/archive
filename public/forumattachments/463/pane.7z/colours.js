  function setUI(font, panel, back, text){ 
    setComponentBackground(panel);
    setBackground(back);
    setLocation(panel, font);
    setInput(panel, font, 14);
    setPanes(text, font, 14);
  }



  function setBackground(c){ 
    s = "background-color: transparent; border: none;"
    document.getElementById("status").setAttribute("style" , "display: none;");
    document.getElementById("controlButtons").setAttribute("style" , s);
    document.getElementById("gameBorder").setAttribute("style" , s + " margin-top: 50px; margin-left: 50px; ");
    document.getElementById("gamePanes").setAttribute("style" , s);
    document.getElementById("gamePanesRunning").setAttribute("style" , s);
    document.body.setAttribute("style" , "background: " + c + ";");
  }


  function setComponentBackground(c){ 
    document.getElementById("gameContent").setAttribute("style" , "background: " + c + ";  width: 600px; border-radius: 15px; border: none");
    document.getElementById("gamePanel").setAttribute("style" , "background: " + c + "; ");
    document.getElementById("gridPanel").setAttribute("style" , "background: " + c + "; ");
    document.getElementById("divOutput").setAttribute("style" , "background: " + c + ";");
    document.getElementById("inventoryLabel").setAttribute("style" , "background: " + c + ";");
    document.getElementById("statusVarsLabel").setAttribute("style" , "background: " + c + ";");
    document.getElementById("placesObjectsLabel").setAttribute("style" , "background: " + c + ";");
    document.getElementById("compassLabel").setAttribute("style" , "background: " + c + ";");
  }

  function setLocation(c, font, size){ 
    document.getElementById("location").setAttribute("style" , "font-family: " + font + "; font-size: 18px; color: " + c + "; padding: 1px; ");
  }
  
  function setInput(c, font, size){ 
    document.getElementById("txtCommand").setAttribute("style" , "font-family: " + font + "; font-size: " + size + "px; color: " + c + "; padding: 3px; border-radius: 15px; width: 580px; ");
  }
  
  function setPanes(c, font, size){ 
    var s = "font-family: " + font + "; font-size: " + size + "px; color: " + c + "; "
    document.getElementById("lstInventory").setAttribute("style" , s);
    document.getElementById("lstPlacesObjects").setAttribute("style" , s);
    document.getElementById("statusVars").setAttribute("style" , s);
    for (var i = 1; i < 10; i++) {
      document.getElementById("cmdPlacesObjects"+i).setAttribute("style" , s);
      document.getElementById("cmdInventory"+i).setAttribute("style" , s);
    }

    s = "font-family: " + font + "; font-size: " + size + "px; color: white; "
    document.getElementById("cmdCompassIn").setAttribute("style" , s);
    document.getElementById("cmdCompassOut").setAttribute("style" , s);

    s = document.getElementById("inventoryLabel").getAttribute("style") + " font-family: " + font + "; font-size: " + size + "px;";
    document.getElementById("inventoryLabel").setAttribute("style" , s);
    document.getElementById("statusVarsLabel").setAttribute("style" , s);
    document.getElementById("placesObjectsLabel").setAttribute("style" , s);
    document.getElementById("compassLabel").setAttribute("style" , s);
  }

  function swap() {
    // Grab the HTML element we are interested in
    rightPane = document.getElementById("gamePanesRunning");
    // ... and its direct child nodes
    nodes = rightPane.childNodes;
    // Save the nodes in a new array
    var ary = new Array();
    s = "Found: " + nodes.length + ". "
    for (i = 0; i < nodes.length; i++) {
      s += " Got: " + nodes[i].id + " (" + nodes[i].tagName + ")" + ". ";
      ary[i] = nodes[i]
    }
    //ASLEvent("jsresult", s)
    // Clear the existing content
    rightPane.innerHTML = '';
    // Add the panes back in, in the new order
    // Some browsers count spaces as nodes, which gives you 17 nodes, where all the even numbered ones
    // can be ignored. Other browsers do not count spaces as nodes, so there are 8, all required.
    order = [3, 1, 0, 2]
    ASLEvent("jsresult", " = Got: " + ary.length)

    if (ary.length == 17) {
      //append(rightPane, ary[0])
      for (i = 0; i < order.length; i++) {
        append(rightPane, ary[order[i] * 4 + 1])
        //append(rightPane, ary[order[i] * 4 + 2])
        append(rightPane, ary[order[i] * 4 + 3])
        //append(rightPane, ary[order[i] * 4 + 4])
      }
      ASLEvent("jsresult", "Started with 17, now have " + rightPane.childNodes.length);
    } else if (ary.length == 8) {
      for (i = 0; i < order.length; i++) {
        append(rightPane, ary[order[i] * 2])
        append(rightPane, ary[order[i] * 2 + 1])
      }
      ASLEvent("jsresult", "Started with 8, now have " + rightPane.childNodes.length);
    } else {
      for (i = 0; i < ary.length; i++) {
        append(rightPane, ary[i])
      }
      ASLEvent("jsresult", "Unexpectedly started with " + ary.length + ", now have " + rightPane.childNodes.length + " in the original order");
    }
  }

  function append(root, node) {
    root.appendChild(node)
    //root.innerHTML += node.outerHTML
    //ASLEvent("jsresult", "node.tagName=" + node.tagName);

    //var newNode = document.createElement(node.tagName);
    //ASLEvent("jsresult", "node.attributes.length=" + node.attributes.length);
    //for (i = 0; i < node.attributes.length; i++) {
      //ASLEvent("jsresult", "node.attributes[i].nodeName=" + node.attributes[i].nodeName);
    //  root.setAttribute(node.attributes[i].nodeName, node.attributes[i].nodeValue);
    //}
    //root.appendChild(newNode);
  }