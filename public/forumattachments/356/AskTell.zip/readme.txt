==Ask-and-tell vs Speak-to/Menu==

Ever pondered whether it is better to implement conversations by having player ask character about subject and tell character about subject, or whether it is better to speak to character, and then off a menu of subjects? Ponder no more!

Now you can have both at the same time, with minimal effort.

===Default Responses===

 Say we are writing a fantasy adventure.  All the people in the land know who the king is,
 so you do not want them to give a default response that they know nothing about the king, but neither do
 you want to add a response to each and every character. Now you do not have to. Add a single response
 to a new character called "default_ask_tell", and if the player asks a character without a specific
 response about the king, the default one is delivered instead (unless you give a specific default response
 which you might want for the magic ring that has been buried for a thousand years).

The character "default_ask_tell" must be set up on the game object.

===Marrying the Speak-To Functionality===

Rather than have the player type "ask boris about the king", the player can click on boris, select
"speak to" and will see a list of topics specific to boris, based on the ask/tell entries for boris. All the
author has to do for each character is set up a verb called "speak to", that will "Call Function" called "Chat"
with the parameter "this".

Also gives you the "topics" command. The player types "topics" and gets a list of topic for the character
present, or types "topics for boris" to specify Boris' topics. This is automatic; the author need do nothing.

===You Already Said That===

The system automatically tracks how often the player asks each character about a specific topic. This value can be accessed
though the "conv_count" attribute for that character.

===Language Support===

Want to do this in another language? 
As well as changing all the templates at the top of this file, you should also modify
the values of two properties of the ask_tell_language_support object.

===Notes===

As is already the case, ask/tell responses are scripts so can react to the state of the game, and you can add
new ask/tell subjects as the game progresses.

You need to include PixLib.aslx as this library uses some functionality from there.

===Tutorial===

1. Set up your characters for Ask/Tell as normal. Remember you can access the conv_count attribute to see how often the player has asked about this topic.

2. Also, for each character, click on the "Verbs" tab, and add a new verb "Speak to". Set this to run a script, and from the list, select "Call function". Type "Chat" in as the name of the function, and add a single parameter, "this" (all without quotes).

3. The next step is to set up your default_ask_tell character. Right click on the "game" object, and select "Create Object". Now click on the Ask/Tell tab, and put in your default responses, just as you would for a normal character.

If unsure, look at the demo. Remember to include this library and PixLib.

