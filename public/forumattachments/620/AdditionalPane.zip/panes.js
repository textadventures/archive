$(function() {
  var s = "<div id='inventory2Holder' style='padding-left:0px'> \
            <h3 id='inventory2Label'><a href='#'>Inventory 2</a></h3> \
            <div id='inventory2Accordion'> \
                <div id='inventory2Wrapper' class='elementListWrapper'> \
                    <ol id='lstInventory2' class='elementList'> \
                    </ol> \
                </div> \
                <div class='verbButtons'> \
                    <button id='otherInventory1' type='button' onclick='paneButtonClick('#lstInventory2',$(this));' style='display:block'>1</button> \
                    <button id='otherInventory2' type='button' onclick='paneButtonClick('#lstInventory2',$(this));' style='display:none'>2</button> \
                    <button id='otherInventory3' type='button' onclick='paneButtonClick('#lstInventory2',$(this));' style='display:none'>3</button> \
                    <button id='otherInventory4' type='button' onclick='paneButtonClick('#lstInventory2',$(this));' style='display:none'>4</button> \
                    <button id='otherInventory5' type='button' onclick='paneButtonClick('#lstInventory2',$(this));' style='display:none'>5</button> \
                    <button id='otherInventory6' type='button' onclick='paneButtonClick('#lstInventory2',$(this));' style='display:none'>6</button> \
                    <button id='otherInventory7' type='button' onclick='paneButtonClick('#lstInventory2',$(this));' style='display:none'></button> \
                    <button id='otherInventory8' type='button' onclick='paneButtonClick('#lstInventory2',$(this));' style='display:none'></button> \
                    <button id='otherInventory9' type='button' onclick='paneButtonClick('#lstInventory2',$(this));' style='display:none'></button> \
                </div> \
            </div> \
            </div>";
    $(s).insertBefore("#statusVarsLabel");
    $("#inventory2Holder").multiOpenAccordion({ active: [0] });
});
