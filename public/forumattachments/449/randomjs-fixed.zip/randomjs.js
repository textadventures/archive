var diceroll=0;
var topnum=0;
function singledice(topnum)
{
window.alert("You roll the dice!");
var diceroll= Math.floor(Math.random()*topnum)+1;
//if (diceroll == 0)
//{
//diceroll = 1;
//}
window.alert("dice roll is " + diceroll);
}