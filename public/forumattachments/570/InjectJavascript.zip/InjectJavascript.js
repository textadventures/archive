﻿function InjectJavascript(script) {
    var elem = document.createElement("script");
    elem.innerHTML = script;
    var tag = document.getElementsByTagName("script")[0];
    tag.parentNode.insertBefore(elem, tag);
}
